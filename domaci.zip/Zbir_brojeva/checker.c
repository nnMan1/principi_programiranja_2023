#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main() {
    char input_file_path[256];
    char correct_output_file_path[256];
    char user_output_file_path[256];

    gets(input_file_path);
    gets(correct_output_file_path);
    gets(user_output_file_path);

    //FILE *input = fopen(input_file_path, "r");
    FILE *correct_output = fopen(correct_output_file_path, "r");
    FILE *user_output = fopen(user_output_file_path, "r");

    double user_res, correct_res;

    fscanf(user_output, "%lf", &user_res);
    fscanf(correct_output, "%lf", &correct_res);

    if(fabs(user_res - correct_res) < 1e-9) {
        printf("1");
        fprintf(stderr, "translate:success");
    } else {
        printf("0");
        fprintf(stderr, "translate:wrong");
    }

    fclose(correct_output);
    fclose(user_output);

    return 0;
}