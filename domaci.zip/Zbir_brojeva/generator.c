#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef union Number Number;

unsigned long long large_random_number(unsigned long long mod) { //koristicemo ovu funkciju da genrisemo cijele brojeve vece od RAND_MAX
    unsigned long long n;

    for (int i=0; i<64; i += 15) {
        n = n*((unsigned long long)RAND_MAX + 1) + rand();
        n %= mod;
    }
    return n;
}

void generate_sample_int(FILE *in, FILE *out, int mod) {
    long long a = large_random_number(2 * mod) - mod;
    long long b = large_random_number(2 * mod) - mod;

    fprintf(in, "%lld %lld", a, b); //upisemo dva broja u ulazni fajl
    fprintf(out, "%lld", a + b); //upisemo rezultat u fajl koji treba da sadrzi rezultat
}

void generate_sample_float(FILE *in, FILE *out) {
    double a = large_random_number(2e9) - 1e9 + (double)large_random_number(2e9) / 2e9; //generisemo cio dio, i dodamo mu razlomnjeni dio
    double b = large_random_number(2e9) - 1e9 + (double)large_random_number(2e9) / 2e9; //generisemo cio dio, i dodamo mu razlomnjeni dio


    fprintf(in, "%lf %lf", a, b); //upisemo dva broja u ulazni fajl
    fprintf(out, "%lf", a + b);

}

int main() {
    srand(time(NULL));

    int subtask;
    int N;

    printf("Unesite podzadatak [1, 2, 3]: ");

    scanf("%d", &subtask);

    if(subtask != 1 && subtask != 2 && subtask != 3) {
        printf("Podzadatak mora biti jedan od brojeva 1, 2 ili 3\n");
        exit(1);
    }

    printf("Unesite broj test primjera: ");
    scanf("%d", &N);

    if(N <= 0) {    
        printf("Broj test pimjera mora biti veci od 0\n");
        exit(1);
    }

    for(int i=0;i<N;i++) {
        char in_file_name[50];
        sprintf(in_file_name, "in_%d_%d.txt", subtask, i);
        FILE *in = fopen(in_file_name, "w");

        char out_file_name[50];
        sprintf(out_file_name, "out_%d_%d.txt", subtask, i);
        FILE *out = fopen(out_file_name, "w");

        switch(subtask) {
            case 1:
                generate_sample_int(in, out, 32000);
                break;
            case 2:
                generate_sample_int(in, out, (int)1e9);
                break;
            case 3:
                generate_sample_float(in, out);
                break;
        }

        fclose(in);
        fclose(out);    
    }
}