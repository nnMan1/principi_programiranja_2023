#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int count_directors(FILE * f) {
    int i = 0;
    char s[100];
    fgets(s, 100, f);

    while(!feof(f)) {
        i++;
        fgets(s, 100, f);
    }

    return i;
}

int director_idx(char * director, FILE * f) {

    rewind(f);

    int i = 0;
    char s[100];
    fgets(s, 100, f);
    s[strlen(s) - 1] = '\0';

    while(!feof(f) && strcmp(director, s) != 0) {
        i++;
        fgets(s, 100, f);
        s[strlen(s) - 1] = '\0';
    }

    return i;
}

char * idx_director(int idx, FILE * f) {
    rewind(f);

    int i = 0;
    char *s = malloc(sizeof(char) * 100);
    fgets(s, 100, f);
    s[strlen(s) - 1] = '\0';

    while(!feof(f)&& i < idx) {
        i++;
        fgets(s, 100, f);
        s[strlen(s) - 1] = '\0';
    }

    return s;
}

void theBest(char episodesInputFile[], char directorsInputFile[], char episodesOputputFile[]) {
    FILE * episodesInput = fopen(episodesInputFile, "r");
    if (episodesInput == NULL) {
        printf("Nije moguce otvoriti fajl %s", episodesInputFile);
        exit(1);
    }

    FILE * directorsInput = fopen(directorsInputFile, "r");
     if (directorsInput == NULL) {
        printf("Nije moguce otvoriti fajl %s", directorsInputFile);
        exit(1);
    }

    FILE * episodesOputput = fopen(episodesOputputFile, "w");
    if (episodesOputput == NULL) {
        printf("Nije moguce otvoriti fajl %s", episodesOputputFile);
        exit(1);
    }

    int n = count_directors(directorsInput);
    float directors_viewers[n];
    int director_episodes[n];

    for(int i=0;i<n;i++) {
        directors_viewers[i] = 0;
        director_episodes[i] = 0;
    }

    char best_episode_names[6][100];
    float best_epis_view[6];

    for(int i=0;i<6;i++)
        best_epis_view[i] = 0;

    char s[1000];
    fgets(s, 1000, episodesInput);

    while(!feof(episodesInput)) {

        char * tmp = strtok(s, "#");
        int no_seas = atoi(tmp);

        tmp = strtok(NULL, "#");
        int no_epis = atoi(tmp);

        char * epis_name = strtok(NULL, "#");
        char * director = strtok(NULL, "#");
        char * scenarists = strtok(NULL, "#");

        tmp = strtok(NULL, "#");
        float no_view = atof(tmp);

         int director_id = director_idx(director, directorsInput);
         director_episodes[director_id] ++;
         directors_viewers[director_id] += no_view;

         if(strstr(scenarists, "Vince Gilligan"))
             directors_viewers[director_id] -= 0.2*no_view;

        if(strstr(scenarists, director))
             directors_viewers[director_id] += 0.4*no_view;

        if(no_view > best_epis_view[no_seas]) {
            best_epis_view[no_seas] = no_view;
            strcpy(best_episode_names[no_seas], epis_name);
        }


        fgets(s, 1000, episodesInput);
    }

    int best_idx = 0;

    for(int i=0;i<n;i++)
        if(directors_viewers[i] / director_episodes[i] > directors_viewers[best_idx] / director_episodes[best_idx] )
            best_idx = i;

    char * best_director_name = idx_director(best_idx, directorsInput);
    printf("%s", best_director_name);
    free(best_director_name);

    for(int i=1;i<6;i++) {
        fprintf(episodesOputput, "%s\n", best_episode_names[i]);
    }

    fclose(episodesInput);
    fclose(directorsInput);
    fclose(episodesOputput);

}

int main()
{
    theBest("episodes.txt", "directors.txt", "episodes_out.txt");
    return 0;
}
